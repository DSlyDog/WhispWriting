package net.whispwriting.whispwriting.bouncycastle;

/**
 * all parameter classes implement this.
 */
public interface CipherParameters
{
}
